<BR><BR><BR><BR>
<HR style="color: rgb(0, 0, 0)" noShade="noshade">

<P align="center"> © 2016 Diario de Centro América - Todos los derechos   
 reservados.</P>